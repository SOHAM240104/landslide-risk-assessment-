from flask import Flask, render_template, request, redirect, url_for, session
import numpy as np
import joblib
import pandas as pd
import folium
import os
import secrets

app = Flask(__name__)
# Generate a secure random secret key
app.secret_key = secrets.token_hex(16)  # This will generate a 32-character random hex string

# Load models and preprocessing tools
occurrence_model = joblib.load("mine/random_forest_landslide_model.pkl")       # Random Forest for occurrence
severity_model = joblib.load("landslide_severity_model.pkl")                   # Severity model
scaler = joblib.load("mine/scaler_occurrence.pkl")                             # Scaler used with severity model
label_encoder = joblib.load("severity_label_encoder.pkl")                      # Encoder for severity

# Define default coordinates for Wayanad, Kerala
WAYANAD_COORDINATES = [11.6854, 76.1320]

@app.route("/")
def home():
    session.clear()  # Clear any existing session data
    return render_template("index.html")

@app.route("/form1", methods=["GET", "POST"])
def form1():
    if request.method == "POST":
        try:
            # Get form input
            slope_value = float(request.form.get("slope_value", 0))
            ndvi_value = float(request.form.get("ndvi_value", 0))
            annual_x = float(request.form.get("annual_x", 0))

            # Store values in session
            session['slope_value'] = slope_value
            session['ndvi_value'] = ndvi_value
            session['annual_x'] = annual_x

            return redirect(url_for('form2'))
        except (ValueError, TypeError) as e:
            error = "Please enter valid numerical values for all fields"
            return render_template("form1.html", error=error)
    
    return render_template("form1.html")

@app.route("/form2", methods=["GET", "POST"])
def form2():
    # Check if we have the required session data
    if not all(key in session for key in ['slope_value', 'ndvi_value', 'annual_x']):
        return redirect(url_for('form1'))

    if request.method == "POST":
        try:
            # Get form input
            risk_factor_x = float(request.form.get("risk_factor_x", 0))
            risk_factor_y = float(request.form.get("risk_factor_y", 0))
            risk_factor_z = float(request.form.get("risk_factor_z", 0))

            # Get values from session
            slope_value = session.get('slope_value')
            ndvi_value = session.get('ndvi_value')
            annual_x = session.get('annual_x')

            if None in [slope_value, ndvi_value, annual_x]:
                return redirect(url_for('form1'))

            print("[INPUT] User form data received:")
            print(f"  Slope Value: {slope_value}")
            print(f"  NDVI Value: {ndvi_value}")
            print(f"  Annual Rainfall (X): {annual_x}")
            print(f"  Risk Factor X: {risk_factor_x}")
            print(f"  Risk Factor Y: {risk_factor_y}")
            print(f"  Risk Factor Z: {risk_factor_z}")

            input_data = np.array([[slope_value, ndvi_value, annual_x, risk_factor_x, risk_factor_y, risk_factor_z]])
            input_df = pd.DataFrame(input_data, columns=[
                'slope_value', 'ndvi_value', 'ANNUAL_x',
                'Risk Factor_x', 'Risk Factor_y', 'Risk Factor_z'
            ])

            # ----------- OCCURRENCE PREDICTION (Random Forest) -----------
            occurrence_features = ['slope_value', 'ndvi_value', 'ANNUAL_x']
            rf_input = input_df[occurrence_features]

            probability = occurrence_model.predict_proba(rf_input)[0][1]
            threshold = 0.6
            occurrence_prediction = int(probability > threshold)
            occurrence_result = "Yes" if occurrence_prediction else "No"

            # ----------- SEVERITY PREDICTION (Logistic model) -----------
            input_df_scaled = input_df.copy()
            input_df_scaled[occurrence_features] = scaler.transform(input_df_scaled[occurrence_features])

            if occurrence_result == "Yes":
                raw_severity = severity_model.predict(input_df_scaled)
                severity_result = label_encoder.inverse_transform(raw_severity)[0]
            else:
                severity_result = "Low"

            # ----------- MAP GENERATION -----------
            map_path = generate_map(occurrence_result, severity_result)

            # Clear session data
            session.clear()

            return render_template("result.html", 
                                occurrence=occurrence_result, 
                                severity=severity_result, 
                                map_path=map_path)

        except (ValueError, TypeError) as e:
            error = "Please enter valid numerical values for all fields"
            return render_template("form2.html", error=error)
        except Exception as e:
            error = str(e)
            print("[ERROR]", error)
            return render_template("form2.html", error=error)
    
    return render_template("form2.html")

def generate_map(occurrence, severity):
    severity_colors = {
        "High": "red",
        "Moderate": "yellow",
        "Low": "green",
        "None": "green"
    }

    popup_text = f"Landslide Severity: {severity}" if occurrence == "Yes" else "No Landslide Occurrence"

    wayanad_map = folium.Map(location=WAYANAD_COORDINATES, zoom_start=10)

    folium.CircleMarker(
        location=WAYANAD_COORDINATES,
        radius=10,
        color=severity_colors.get(severity, "blue"),
        fill=True,
        fill_color=severity_colors.get(severity, "blue"),
        fill_opacity=0.7,
        popup=popup_text
    ).add_to(wayanad_map)

    if not os.path.exists("static"):
        os.makedirs("static")

    map_file = "static/wayanad_map.html"
    wayanad_map.save(map_file)
    return map_file

@app.route('/visualization')
def visualization():
    return render_template('visualization.html')

@app.route('/preprocessing')
def preprocessing():
    return render_template('preprocessing.html')

@app.route('/feature-extraction')
def feature_extraction():
    return render_template('feature_extraction.html')

if __name__ == "__main__":
    app.run(debug=True)
